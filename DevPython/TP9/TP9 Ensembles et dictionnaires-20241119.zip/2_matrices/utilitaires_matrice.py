""" Fonctions utilitaires pour manipuler les matrices """

import API_matrice1 as matrice_util


