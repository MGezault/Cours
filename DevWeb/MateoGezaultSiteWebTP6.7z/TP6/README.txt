Je vous présente mon site HTML présentant la série Arcane, une série animée qui se passe dans l'univers du Jeu Vidéo
League Of Legends, et plus précisement dans la villes de Piltover et celle de Zaun.
Sur ce site vous pourrez retrouver divers pages qui concernent certains personnages choisis mais aussi des liens vers l'extérieur 
comme vers des réseaux Sociaux ou alors vers d'autres pages du site.

J'ai fais du travail supplémentaire comparé au schéma initial, surtout par rapport aux borders, j'ai rajouté des borders sur 
différents élement afin de rajouter du relief sur le site et de créer quelque chose de cohérent visuellement.