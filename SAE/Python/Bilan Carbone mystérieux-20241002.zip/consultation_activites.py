import bilan_carbone as bc

# Ici vos fonctions dédiées aux interactions

# ici votre programme principal
def programme_principal():
    ...
